<?php

$db = new mysqli("localhost", "root", "", "guidcouns");

if ($db->connect_error) {
    die("Connection Error: " . $db->connect_error);
} 

?>