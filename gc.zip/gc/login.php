<?php

include('database.php');

$idno = mysqli_real_escape_string($db, $_POST['idno']);
$password = mysqli_real_escape_string($db, $_POST['password']);

$query = 'select * from users where idno = "'.$idno.'"';
$result = $db->query($query);
$row = $result->fetch_assoc();

$count = $result->num_rows;

if($count == 1) {
	if(password_verify($password, $row['password'])) {
		session_start();
		$_SESSION['idno'] = $idno;
		header("location: index.php");
	}
} else {
	echo "<script> alert('Invalid Id no. or password'); window.history.back(); </script>";
}

?>