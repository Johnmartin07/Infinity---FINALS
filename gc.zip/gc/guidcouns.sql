CREATE DATABASE IF NOT EXISTS `guidcouns`;
USE `guidcouns`;

-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 16, 2019 at 12:36 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idno` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `idno`, `password`) VALUES
(3, 'John', '$2y$10$q/yMGzW6uyE7iBo.IshcXerni6UCXR5eAek81dTkEMMUQLDpyVboG'),
(4, 'Test', '$2y$10$K3xG8wWjNl6ngGjNgES4veT0dLZluShPHkw4K5cjZxhwcMpy9lTOG'),
(5, '2153882', '$2y$10$aEESRrz46IqRZLuzaOJCBe4eb7HMulpIx9s0vwulvJJKFNN0xg9kC'),
(6, 'jeco', '$2y$10$Z3STW5mYqKCJ9jnUTkDWnuwLIrZToKeJNAJYVkL6iUB6uYFmOSjJy'),
(7, 'yema', '$2y$10$g4SPE9hbhf/Yxl5ZnCOPVuRQBGiBs7k.YF/r.hFpLIZTjPij9mtSG');
COMMIT;
